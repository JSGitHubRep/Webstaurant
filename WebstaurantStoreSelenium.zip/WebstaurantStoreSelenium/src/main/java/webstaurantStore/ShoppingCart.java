package webstaurantStore;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;


public class ShoppingCart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.navigate().to("https://www.webstaurantstore.com/");
		driver.manage().window().maximize();

		driver.findElement(By.id("searchval")).sendKeys("stainless work table", Keys.ENTER);

		boolean hasNextPage = true;//Variable used to navigate to next pages

		int itemfoundcount;//To access last found item
		while (hasNextPage) {
			//get the list of products in the page for the search condition
			List<WebElement> listOfProducts = driver.findElements(By.xpath("//div[@id='product_listing']/div"));
			itemfoundcount = 1;
			for (int i = 1; i <= listOfProducts.size(); i++)

			{
				String str_itemDescription = driver
						.findElement(By.xpath(
								"//div[@id='product_listing']/div[" + i + "]/div[2]/a[@data-testid='itemDescription']"))
						.getText();
				//Condition to check whether text 'Table' exist
				if (str_itemDescription.contains("Table")) {

					itemfoundcount = i;

				} else {
					System.out.println(str_itemDescription + " = The item description does not contains table");
				}

			}
			
			//Find next button to navigate through pages
			List<WebElement> enabled_next_page_btn = driver
					.findElements(By.xpath("//li[@class='rc-pagination-next'][@aria-disabled='false']"));
			
			if (enabled_next_page_btn.size() > 0) {
				enabled_next_page_btn.get(0).click();
				hasNextPage = true;
			} else {
				hasNextPage = false;
				System.out.println("No more Pages Available");
				//Add the item to cart
				driver.findElement(By.xpath("//div[@id='product_listing']/div[" + itemfoundcount
						+ "]/div[4]/form/div/div/input[@name='addToCartButton']")).click();
			}
		}
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		
		//Some items are required to select accessories so find the accessory window pop up
		List<WebElement> accessory_popup = driver
				.findElements(By.name("accessories"));
		
		//if accessory window pops up, select required accessory from drop down list and add to cart
		if (accessory_popup.size() > 0) {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("accessories")));
			Select dropdown = new Select(driver.findElement(By.name("accessories")));
			dropdown.selectByIndex(3);
			driver.findElement(By.xpath("//button[text()='Add To Cart']")).click();
		}
		 
		//Wait for view cart popup and find delete the item added in the cart
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("View Cart"))).click();
		Thread.sleep(5000);//Just to show the cart with item added for few seconds
		driver.findElement(By.className("itemDelete__icon")).click();
		System.out.println(
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//p[text()='Your cart is empty.']")))
						.getText());
	}
}

